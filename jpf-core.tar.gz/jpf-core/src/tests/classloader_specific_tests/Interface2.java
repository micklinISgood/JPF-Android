package classloader_specific_tests;

public interface Interface2 {
}
