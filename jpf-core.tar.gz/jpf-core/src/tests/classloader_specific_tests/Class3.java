package classloader_specific_tests;

public class Class3 {
  public static void assertFalse() {
    assert false;
  }
}
