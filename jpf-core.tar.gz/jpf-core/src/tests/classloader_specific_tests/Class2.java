package classloader_specific_tests;

public class Class2 {
  public static void assertFalse() {
    assert false;
  }
}
