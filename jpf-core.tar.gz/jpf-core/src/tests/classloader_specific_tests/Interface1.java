package classloader_specific_tests;

public interface Interface1 {
	final static Class3 f = new Class3();
}
